package com.Final.RestService.Springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalRestServiceSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
